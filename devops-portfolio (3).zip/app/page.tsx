"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Github,
  Linkedin,
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  Cloud,
  Server,
  Shield,
  Zap,
  GitBranch,
  Monitor,
  ChevronDown,
  Send,
  Calendar,
  Building,
  Award,
  Container,
  FileCode,
  X,
  ChevronLeft,
  ChevronRight,
  Download,
  Code,
  Sparkles,
  Rocket,
  Target,
  TrendingUp,
  Globe,
  CheckCircle,
  BookOpen,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function ProfessionalDevOpsPortfolio() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeSection, setActiveSection] = useState("hero")
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isLoaded, setIsLoaded] = useState(false)
  const heroRef = useRef<HTMLElement>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
    setIsLoaded(true)
    setIsVisible(true)

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    const handleScroll = () => {
      const sections = ["hero", "about", "skills", "certifications", "experience", "projects", "contact"]
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  const skills = [
    {
      category: "Cloud Platforms",
      items: [
        { name: "AWS", logo: "/logos/aws.png" },
        { name: "Azure", logo: "/logos/azure.png" },
        { name: "Google Cloud", logo: "/logos/gcp.png" },
        { name: "DigitalOcean", logo: "/placeholder.svg?height=32&width=32&text=DO" },
      ],
      icon: <Cloud className="h-6 w-6" />,
      color: "from-blue-500 to-cyan-500",
    },
    {
      category: "Container & Orchestration",
      items: [
        { name: "Docker", logo: "/logos/docker.png" },
        { name: "Kubernetes", logo: "/logos/kubernetes.png" },
        { name: "OpenShift", logo: "/placeholder.svg?height=32&width=32&text=OpenShift" },
        { name: "Helm", logo: "/placeholder.svg?height=32&width=32&text=Helm" },
      ],
      icon: <Container className="h-6 w-6" />,
      color: "from-purple-500 to-pink-500",
    },
    {
      category: "CI/CD",
      items: [
        { name: "Jenkins", logo: "/logos/jenkins.png" },
        { name: "GitLab CI", logo: "/placeholder.svg?height=32&width=32&text=GitLab" },
        { name: "GitHub Actions", logo: "/placeholder.svg?height=32&width=32&text=GitHub" },
        { name: "Azure DevOps", logo: "/placeholder.svg?height=32&width=32&text=AzureDevOps" },
      ],
      icon: <GitBranch className="h-6 w-6" />,
      color: "from-green-500 to-emerald-500",
    },
    {
      category: "Infrastructure as Code",
      items: [
        { name: "Terraform", logo: "/logos/terraform.png" },
        { name: "CloudFormation", logo: "/placeholder.svg?height=32&width=32&text=CloudFormation" },
        { name: "Ansible", logo: "/logos/ansible.png" },
        { name: "Pulumi", logo: "/placeholder.svg?height=32&width=32&text=Pulumi" },
      ],
      icon: <FileCode className="h-6 w-6" />,
      color: "from-orange-500 to-red-500",
    },
    {
      category: "Monitoring & Logging",
      items: [
        { name: "Prometheus", logo: "/logos/prometheus.png" },
        { name: "Grafana", logo: "/logos/grafana.png" },
        { name: "ELK Stack", logo: "/placeholder.svg?height=32&width=32&text=ELK" },
        { name: "Datadog", logo: "/placeholder.svg?height=32&width=32&text=Datadog" },
      ],
      icon: <Monitor className="h-6 w-6" />,
      color: "from-yellow-500 to-orange-500",
    },
    {
      category: "Security & Compliance",
      items: [
        { name: "HashiCorp Vault", logo: "/placeholder.svg?height=32&width=32&text=Vault" },
        { name: "OWASP", logo: "/placeholder.svg?height=32&width=32&text=OWASP" },
        { name: "SIEM", logo: "/placeholder.svg?height=32&width=32&text=SIEM" },
        { name: "SonarQube", logo: "/placeholder.svg?height=32&width=32&text=SonarQube" },
      ],
      icon: <Shield className="h-6 w-6" />,
      color: "from-red-500 to-pink-500",
    },
  ]

  const certifications = [
    {
      name: "Microsoft Azure Fundamentals",
      code: "AZ-900",
      issuer: "Microsoft",
      date: "2024",
      logo: "/logos/azure.png",
      description: "Foundational knowledge of cloud services and how those services are provided with Microsoft Azure.",
      skills: ["Cloud Computing", "Azure Services", "Security", "Compliance", "Pricing"],
      credentialUrl: "#", // Replace with actual credential URL
      color: "from-blue-500 to-cyan-500",
    },
  ]

  const education = [
    {
      degree: "Bachelor of Science in Computer Science",
      institution: "University of Tunis El Manar",
      period: "2021 - 2024",
      location: "Tunis, Tunisia",
      description:
        "Focused on software development, algorithms, data structures, and network security. Completed several projects involving cloud technologies and distributed systems.",
      courses: [
        "Cloud Computing Architectures",
        "Operating Systems",
        "Database Management Systems",
        "Network Security",
        "Distributed Systems",
      ],
      color: "from-green-500 to-emerald-500",
    },
    {
      degree: "Preparatory Cycle in Engineering",
      institution: "Higher Institute of Applied Sciences and Technology of Sousse",
      period: "2019 - 2021",
      location: "Sousse, Tunisia",
      description:
        "Intensive two-year program focusing on mathematics, physics, and computer science fundamentals, preparing for engineering studies.",
      courses: ["Advanced Mathematics", "Physics for Engineers", "Algorithmics", "Programming Fundamentals"],
      color: "from-purple-500 to-pink-500",
    },
  ]

  const experience = [
    {
      title: "DevOps Intern",
      company: "TechCorp Solutions",
      period: "2024 - Present",
      location: "Remote",
      description:
        "Gained hands-on experience with infrastructure automation and deployment processes while supporting senior engineers in multi-cloud environments.",
      achievements: [
        "Assisted in deploying applications to AWS and Azure environments",
        "Learned GitOps workflows and CI/CD pipeline implementation",
        "Contributed to monitoring setup using Prometheus and Grafana",
        "Participated in infrastructure automation using Terraform",
      ],
      technologies: ["AWS", "Kubernetes", "Terraform", "Jenkins", "Prometheus"],
    },
    {
      title: "Cloud Computing Student",
      company: "University Project",
      period: "2023 - 2024",
      location: "Tunisia",
      description:
        "Completed comprehensive coursework and hands-on projects in cloud computing, DevOps practices, and infrastructure management.",
      achievements: [
        "Built and deployed 10+ projects using various cloud platforms",
        "Implemented CI/CD pipelines for academic projects",
        "Learned containerization with Docker and Kubernetes",
        "Achieved high grades in cloud computing and system administration courses",
      ],
      technologies: ["AWS", "Docker", "Ansible", "GitLab CI", "Linux"],
    },
    {
      title: "IT Support Volunteer",
      company: "Local Tech Community",
      period: "2022 - 2023",
      location: "Tunisia",
      description:
        "Volunteered to provide IT support and learned foundational DevOps practices while helping local businesses with their technology needs.",
      achievements: [
        "Provided technical support for small businesses",
        "Set up basic monitoring and backup systems",
        "Learned Linux system administration",
        "Gained experience with networking and security basics",
      ],
      technologies: ["Linux", "Bash", "Networking", "System Administration"],
    },
  ]

  const projects = [
    {
      title: "Multi-Cloud Kubernetes Platform",
      description:
        "Enterprise-grade Kubernetes platform spanning AWS, Azure, and GCP with automated failover, disaster recovery, and advanced security features.",
      longDescription:
        "A comprehensive multi-cloud orchestration platform that provides seamless workload distribution across major cloud providers. Features include automated failover, disaster recovery, cost optimization, and advanced security policies.",
      tech: ["Kubernetes", "Terraform", "ArgoCD", "Prometheus", "Istio", "Helm"],
      images: [
        "/projects/kubernetes-platform/dashboard.jpg",
        "/projects/kubernetes-platform/architecture.jpg",
        "/projects/kubernetes-platform/monitoring.jpg",
      ],
      github: "https://github.com/hmaidimohamed/k8s-multicloud",
      demo: "https://k8s-demo.hmaidimohamed.dev",
      featured: true,
      metrics: {
        uptime: "99.9%",
        cost_reduction: "40%",
        deployment_speed: "75% faster",
      },
    },
    {
      title: "Serverless CI/CD Pipeline",
      description:
        "Fully automated serverless deployment pipeline with security scanning, testing, blue-green deployments, and compliance reporting.",
      longDescription:
        "A cutting-edge serverless CI/CD solution that automatically handles code deployment, security scanning, testing, and compliance reporting. Features blue-green deployments and automatic rollback capabilities.",
      tech: ["AWS Lambda", "GitHub Actions", "CloudFormation", "Python", "SonarQube", "Terraform"],
      images: [
        "/projects/cicd-pipeline/pipeline-overview.jpg",
        "/projects/cicd-pipeline/security-scan.jpg",
        "/projects/cicd-pipeline/deployment.jpg",
      ],
      github: "https://github.com/hmaidimohamed/serverless-cicd",
      demo: "https://cicd-demo.hmaidimohamed.dev",
      featured: true,
      metrics: {
        deployment_time: "5 minutes",
        security_score: "A+",
        automation: "100%",
      },
    },
    {
      title: "Infrastructure Monitoring Suite",
      description:
        "Comprehensive monitoring solution with custom dashboards, intelligent alerting, and automated remediation capabilities.",
      longDescription:
        "An advanced monitoring platform that provides real-time insights into infrastructure health, performance metrics, and automated incident response. Features predictive analytics and machine learning-based anomaly detection.",
      tech: ["Prometheus", "Grafana", "AlertManager", "Ansible", "Python", "InfluxDB"],
      images: ["/projects/monitoring-suite/grafana-dashboard.jpg", "/projects/monitoring-suite/alerts.jpg"],
      github: "https://github.com/hmaidimohamed/monitoring-suite",
      demo: "https://monitoring-demo.hmaidimohamed.dev",
      featured: false,
      metrics: {
        response_time: "< 30s",
        accuracy: "99.5%",
        incidents_prevented: "200+",
      },
    },
    {
      title: "Container Security Scanner",
      description:
        "Automated container vulnerability scanning integrated into CI/CD pipelines with policy enforcement and compliance reporting.",
      longDescription:
        "A comprehensive security solution that automatically scans container images for vulnerabilities, enforces security policies, and generates compliance reports. Integrates seamlessly with existing CI/CD workflows.",
      tech: ["Docker", "Trivy", "OPA", "Kubernetes", "Go", "PostgreSQL"],
      images: [
        "/projects/security-scanner/scan-results.jpg",
        "/projects/security-scanner/policy-dashboard.jpg",
        "/projects/security-scanner/integration.jpg",
      ],
      github: "https://github.com/hmaidimohamed/container-security",
      demo: "https://security-demo.hmaidimohamed.dev",
      featured: false,
      metrics: {
        vulnerabilities_detected: "10,000+",
        false_positives: "< 2%",
        scan_time: "< 2 minutes",
      },
    },
  ]

  const stats = [
    { label: "Fresh Graduate", value: "2024", icon: <Calendar className="h-6 w-6" /> },
    { label: "Projects Built", value: "15+", icon: <Rocket className="h-6 w-6" /> },
    { label: "Technologies Learned", value: "20+", icon: <TrendingUp className="h-6 w-6" /> },
    { label: "Certifications", value: "1+", icon: <Award className="h-6 w-6" /> },
  ]

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  const openGallery = (project: any, imageIndex = 0) => {
    setSelectedProject(project)
    setCurrentImageIndex(imageIndex)
  }

  const closeGallery = () => {
    setSelectedProject(null)
    setCurrentImageIndex(0)
  }

  const nextImage = () => {
    if (selectedProject) {
      setCurrentImageIndex((prev) => (prev === selectedProject.images.length - 1 ? 0 : prev + 1))
    }
  }

  const prevImage = () => {
    if (selectedProject) {
      setCurrentImageIndex((prev) => (prev === 0 ? selectedProject.images.length - 1 : prev - 1))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-x-hidden">
      {/* Animated Background with Particles */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -inset-10 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/2 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
        </div>

        {/* Floating Particles */}
        {isMounted && (
          <div className="absolute inset-0">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 bg-white/20 rounded-full animate-float"
                style={{
                  left: `${(i * 7 + 10) % 90}%`,
                  top: `${(i * 11 + 15) % 85}%`,
                  animationDelay: `${(i * 0.3) % 5}s`,
                  animationDuration: `${3 + (i % 4)}s`,
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Enhanced Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-black/10 backdrop-blur-xl border-b border-white/10 transition-all duration-300">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-xl flex items-center justify-center transform hover:scale-110 transition-all duration-300">
                  <Server className="h-6 w-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-ping"></div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full"></div>
              </div>
              <div>
                <span className="text-white font-bold text-xl bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                  Hmaidi Mohamed
                </span>
                <p className="text-white/60 text-sm">Junior DevOps Engineer</p>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              {["about", "skills", "certifications", "experience", "projects", "contact"].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`relative text-sm font-medium transition-all duration-300 hover:text-cyan-400 group ${
                    activeSection === section ? "text-cyan-400" : "text-white/80"
                  }`}
                >
                  {section.charAt(0).toUpperCase() + section.slice(1)}
                  <span
                    className={`absolute -bottom-1 left-0 w-full h-0.5 bg-gradient-to-r from-cyan-400 to-purple-400 transform origin-left transition-transform duration-300 ${
                      activeSection === section ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                    }`}
                  />
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:text-cyan-400 hover:bg-white/10 transition-all duration-300"
                asChild
              >
                <Link href="https://github.com/hmaidimohamed" target="_blank">
                  <Github className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:text-cyan-400 hover:bg-white/10 transition-all duration-300"
                asChild
              >
                <Link href="https://linkedin.com/in/hmaidimohamed" target="_blank">
                  <Linkedin className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="sm"
                className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white border-0 transform hover:scale-105 transition-all duration-300"
                asChild
              >
                <Link href="/resume.pdf" target="_blank">
                  <Download className="mr-2 h-4 w-4" />
                  Resume
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} id="hero" className="relative min-h-screen flex items-center justify-center px-6 pt-20">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div
              className={`space-y-8 transform transition-all duration-1000 ${
                isVisible ? "translate-x-0 opacity-100" : "-translate-x-10 opacity-0"
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-cyan-400 font-medium">
                  <Sparkles className="h-5 w-5 animate-pulse" />
                  <span>Welcome to my digital space</span>
                </div>

                <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight">
                  <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-gradient">
                    Hmaidi
                  </span>
                  <br />
                  <span className="text-white">Mohamed</span>
                </h1>

                <div className="space-y-2">
                  <p className="text-2xl md:text-3xl text-white/90 font-light">Junior DevOps & Cloud Engineer</p>
                  <p className="text-lg text-white/70 max-w-xl leading-relaxed">
                    Fresh graduate passionate about DevOps and cloud technologies. Eager to transform infrastructure
                    with automation, scalable solutions, and modern practices. Ready to contribute to the future of
                    DevOps!
                  </p>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {stats.map((stat, index) => (
                  <div
                    key={index}
                    className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105"
                    style={{ animationDelay: `${index * 200}ms` }}
                  >
                    <div className="text-cyan-400 mb-2">{stat.icon}</div>
                    <div className="text-2xl font-bold text-white">{stat.value}</div>
                    <div className="text-white/60 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white border-0 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-cyan-500/25"
                  onClick={() => scrollToSection("projects")}
                >
                  <Rocket className="mr-2 h-5 w-5" />
                  View My Work
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white/30 text-white hover:bg-white/10 transform hover:scale-105 transition-all duration-300 bg-transparent backdrop-blur-sm"
                  onClick={() => scrollToSection("contact")}
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Let's Connect
                </Button>
              </div>
            </div>

            {/* Right Content - 3D Profile */}
            <div
              className={`relative transform transition-all duration-1000 delay-300 ${
                isVisible ? "translate-x-0 opacity-100" : "translate-x-10 opacity-0"
              }`}
            >
              <div className="relative">
                {/* Floating Elements */}
                <div className="absolute -top-10 -left-10 w-20 h-20 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full opacity-20 animate-float"></div>
                <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-20 animate-float animation-delay-2000"></div>

                {/* Main Profile Container */}
                <div className="relative bg-gradient-to-r from-cyan-400/20 to-purple-400/20 rounded-3xl p-8 backdrop-blur-sm border border-white/10">
                  <div className="relative">
                    <div className="w-80 h-80 mx-auto rounded-2xl bg-gradient-to-r from-cyan-400 to-purple-400 p-1 transform hover:scale-105 transition-all duration-500">
                      <Image
                        src="/profile/hmaidi-mohamed.jpg"
                        alt="Hmaidi Mohamed - DevOps Engineer"
                        width={320}
                        height={320}
                        className="rounded-2xl object-cover w-full h-full"
                      />
                    </div>

                    {/* Floating Tech Icons */}
                    <div className="absolute -top-4 -right-4 w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center animate-bounce">
                      <Cloud className="h-6 w-6 text-white" />
                    </div>
                    <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center animate-bounce animation-delay-1000">
                      <Container className="h-6 w-6 text-white" />
                    </div>
                    <div className="absolute top-1/2 -right-8 w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center animate-pulse">
                      <Code className="h-5 w-5 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown className="h-8 w-8 text-white/60" />
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="relative py-24 px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
              About{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Me</span>
            </h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
              I'm a passionate junior DevOps engineer and fresh graduate eager to build resilient, scalable
              infrastructure. My academic background and hands-on projects have given me solid foundations in cloud
              platforms, containerization, and automation.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {[
              {
                icon: <Shield className="h-12 w-12" />,
                title: "Security First",
                description:
                  "Implementing zero-trust architecture and security best practices throughout the entire development lifecycle",
                color: "from-red-500 to-pink-500",
              },
              {
                icon: <Zap className="h-12 w-12" />,
                title: "Automation Expert",
                description:
                  "Automating everything from infrastructure provisioning to deployment pipelines, reducing manual errors by 95%",
                color: "from-yellow-500 to-orange-500",
              },
              {
                icon: <Monitor className="h-12 w-12" />,
                title: "Observability",
                description:
                  "Building comprehensive monitoring, logging, and alerting systems for proactive issue resolution",
                color: "from-green-500 to-emerald-500",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 animate-fade-in-up group"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-8 text-center">
                  <div
                    className={`inline-flex p-4 rounded-2xl bg-gradient-to-r ${item.color} mb-6 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <div className="text-white">{item.icon}</div>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-4">{item.title}</h3>
                  <p className="text-white/70 leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Personal Touch */}
          <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-3xl p-8 backdrop-blur-sm border border-white/10">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold text-white mb-4">My Journey</h3>
                <p className="text-white/80 leading-relaxed mb-4">
                  Fresh graduate with a passion for DevOps and cloud technologies. During my studies, I focused on
                  learning modern infrastructure practices, automation tools, and cloud platforms through hands-on
                  projects and internships.
                </p>
                <p className="text-white/80 leading-relaxed">
                  I'm eager to start my professional journey, contribute to innovative projects, and continue learning
                  from experienced engineers while bringing fresh perspectives to DevOps challenges.
                </p>
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Globe className="h-5 w-5 text-cyan-400" />
                  <span className="text-white">Based in Tunisia, Working Globally</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Target className="h-5 w-5 text-purple-400" />
                  <span className="text-white">Focus: Cloud-Native Solutions</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-green-400" />
                  <span className="text-white">Azure Certified Professional</span>
                </div>
              </div>
            </div>
          </div>

          {/* Education Section */}
          <div className="mt-24">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
                Education{" "}
                <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Path</span>
              </h2>
              <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
                My academic background has provided me with a strong foundation in computer science and cloud
                technologies.
              </p>
            </div>

            <div className="space-y-8">
              {education.map((edu, index) => (
                <Card
                  key={index}
                  className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 animate-fade-in-up group overflow-hidden"
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="md:col-span-2">
                        <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                          <div>
                            <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors duration-300">
                              {edu.degree}
                            </h3>
                            <div className="flex flex-wrap items-center gap-4 text-cyan-400 mb-4">
                              <div className="flex items-center space-x-2">
                                <Building className="h-4 w-4" />
                                <span className="font-medium">{edu.institution}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Calendar className="h-4 w-4" />
                                <span>{edu.period}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <MapPin className="h-4 w-4" />
                                <span>{edu.location}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <p className="text-white/80 mb-6 leading-relaxed">{edu.description}</p>

                        <div className="space-y-3">
                          <h4 className="text-white font-semibold mb-3 flex items-center">
                            <BookOpen className="h-4 w-4 text-cyan-400 mr-2" />
                            Key Courses
                          </h4>
                          {edu.courses.map((course, courseIndex) => (
                            <div key={courseIndex} className="flex items-start space-x-3 group/course">
                              <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full mt-2 group-hover/course:scale-150 transition-transform duration-300" />
                              <span className="text-white/70 leading-relaxed group-hover/course:text-white transition-colors duration-300">
                                {course}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h4 className="text-white font-semibold">Relevant Skills</h4>
                        <div className="flex flex-wrap gap-2">
                          {edu.courses.map((course, courseIndex) => (
                            <Badge
                              key={courseIndex}
                              className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border-cyan-400/30 hover:bg-cyan-400/10 transition-all duration-300"
                            >
                              {course.split(" ")[0]} {/* Simple example: take first word as skill */}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Skills Section */}
      <section id="skills" className="relative py-24 px-6 bg-black/20">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
              Technical{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Expertise
              </span>
            </h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
              Mastering the tools and technologies that drive modern infrastructure and cloud-native applications
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skillGroup, index) => (
              <Card
                key={index}
                className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 transform hover:scale-105 animate-fade-in-up group"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div
                      className={`p-3 rounded-xl bg-gradient-to-r ${skillGroup.color} group-hover:scale-110 transition-transform duration-300`}
                    >
                      <div className="text-white">{skillGroup.icon}</div>
                    </div>
                    <CardTitle className="text-white text-lg">{skillGroup.category}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {skillGroup.items.map((skill, skillIndex) => (
                    <div key={skillIndex} className="flex items-center space-x-3 group/skill">
                      <div className="w-8 h-8 flex-shrink-0">
                        <Image
                          src={skill.logo || "/placeholder.svg"}
                          alt={`${skill.name} logo`}
                          width={32}
                          height={32}
                          className="w-full h-full object-contain group-hover/skill:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <span className="text-white font-medium group-hover/skill:text-cyan-100 transition-colors duration-300">
                        {skill.name}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="relative py-24 px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
              Professional{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Certifications
              </span>
            </h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
              Validated expertise through industry-recognized certifications that demonstrate my commitment to
              continuous learning and professional development
            </p>
          </div>

          <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {certifications.map((cert, index) => (
              <Card
                key={index}
                className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 transform hover:scale-105 animate-fade-in-up group overflow-hidden"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-8">
                  <div className="flex items-start space-x-6">
                    {/* Certification Logo */}
                    <div className="flex-shrink-0">
                      <div
                        className={`w-20 h-20 bg-gradient-to-r ${cert.color} rounded-2xl p-1 group-hover:scale-110 transition-transform duration-300`}
                      >
                        <div className="w-full h-full bg-white rounded-xl flex items-center justify-center">
                          <Image
                            src={cert.logo || "/placeholder.svg"}
                            alt={`${cert.name} logo`}
                            width={60}
                            height={60}
                            className="w-12 h-12 object-contain"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Certification Details */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-xl font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors duration-300">
                            {cert.name}
                          </h3>
                          <div className="flex items-center space-x-3 text-cyan-400 mb-2">
                            <span className="font-semibold">{cert.code}</span>
                            <span>•</span>
                            <span>{cert.issuer}</span>
                            <span>•</span>
                            <span>{cert.date}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-5 w-5 text-green-400" />
                          <span className="text-green-400 text-sm font-medium">Verified</span>
                        </div>
                      </div>

                      <p className="text-white/80 mb-4 leading-relaxed">{cert.description}</p>

                      {/* Skills Covered */}
                      <div className="mb-4">
                        <h4 className="text-white font-semibold mb-2 text-sm">Skills Covered:</h4>
                        <div className="flex flex-wrap gap-2">
                          {cert.skills.map((skill, skillIndex) => (
                            <Badge
                              key={skillIndex}
                              className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border-cyan-400/30 text-xs"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Credential Link */}
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-cyan-400/30 text-cyan-400 hover:bg-cyan-400/10 bg-transparent transition-all duration-300"
                        asChild
                      >
                        <Link href={cert.credentialUrl} target="_blank">
                          <ExternalLink className="mr-2 h-3 w-3" />
                          View Credential
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Future Certifications */}
          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-3xl p-8 backdrop-blur-sm border border-white/10 max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold text-white mb-4">Next Certifications</h3>
              <p className="text-white/80 mb-6">
                Continuously expanding my expertise with upcoming certifications in cloud platforms and DevOps tools
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                {["AWS Solutions Architect", "Kubernetes Administrator", "Terraform Associate"].map((cert, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="border-white/30 text-white/70 hover:border-cyan-400/50 hover:text-cyan-400 transition-all duration-300"
                  >
                    {cert}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Experience Section */}
      <section id="experience" className="relative py-24 px-6 bg-black/20">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
              Professional{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Journey
              </span>
            </h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
              Building robust infrastructure solutions across diverse industries and scaling teams
            </p>
          </div>

          <div className="space-y-8">
            {experience.map((exp, index) => (
              <Card
                key={index}
                className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 animate-fade-in-up group overflow-hidden"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-8">
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="md:col-span-2">
                      <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                        <div>
                          <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors duration-300">
                            {exp.title}
                          </h3>
                          <div className="flex flex-wrap items-center gap-4 text-cyan-400 mb-4">
                            <div className="flex items-center space-x-2">
                              <Building className="h-4 w-4" />
                              <span className="font-medium">{exp.company}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Calendar className="h-4 w-4" />
                              <span>{exp.period}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <MapPin className="h-4 w-4" />
                              <span>{exp.location}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <p className="text-white/80 mb-6 leading-relaxed">{exp.description}</p>

                      <div className="space-y-3">
                        <h4 className="text-white font-semibold mb-3 flex items-center">
                          <Award className="h-4 w-4 text-cyan-400 mr-2" />
                          Key Achievements
                        </h4>
                        {exp.achievements.map((achievement, achIndex) => (
                          <div key={achIndex} className="flex items-start space-x-3 group/achievement">
                            <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full mt-2 group-hover/achievement:scale-150 transition-transform duration-300" />
                            <span className="text-white/70 leading-relaxed group-hover/achievement:text-white transition-colors duration-300">
                              {achievement}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-white font-semibold">Technologies Used</h4>
                      <div className="flex flex-wrap gap-2">
                        {exp.technologies.map((tech, techIndex) => (
                          <Badge
                            key={techIndex}
                            className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border-cyan-400/30 hover:bg-cyan-400/10 transition-all duration-300"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Projects Section */}
      <section id="projects" className="relative py-24 px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
              Featured{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Projects
              </span>
            </h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
              Showcasing innovative solutions that drive business success and technical excellence
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <Card
                key={index}
                className={`bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 transform hover:scale-105 animate-fade-in-up group overflow-hidden ${
                  project.featured ? "md:col-span-2 lg:col-span-1" : ""
                }`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="relative overflow-hidden cursor-pointer" onClick={() => openGallery(project, 0)}>
                  <Image
                    src={project.images[0] || "/placeholder.svg"}
                    alt={project.title}
                    width={600}
                    height={300}
                    className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Project Metrics Overlay */}
                  <div className="absolute top-4 left-4 space-y-2">
                    {project.featured && (
                      <Badge className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white">
                        <Sparkles className="mr-1 h-3 w-3" />
                        Featured
                      </Badge>
                    )}
                  </div>

                  {/* Gallery indicator */}
                  {project.images.length > 1 && (
                    <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1 text-white text-sm">
                      {project.images.length} photos
                    </div>
                  )}

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="text-white text-center">
                      <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
                        <ExternalLink className="h-6 w-6" />
                      </div>
                      <p className="text-sm">View Gallery</p>
                    </div>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">
                      {project.title}
                    </h3>
                  </div>

                  <p className="text-white/70 mb-4 leading-relaxed">{project.description}</p>

                  {/* Project Metrics */}
                  {project.metrics && (
                    <div className="grid grid-cols-3 gap-4 mb-4 p-3 bg-white/5 rounded-lg">
                      {Object.entries(project.metrics).map(([key, value], metricIndex) => (
                        <div key={metricIndex} className="text-center">
                          <div className="text-cyan-400 font-bold text-sm">{value}</div>
                          <div className="text-white/60 text-xs capitalize">{key.replace("_", " ")}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tech.map((tech, techIndex) => (
                      <Badge
                        key={techIndex}
                        variant="outline"
                        className="border-cyan-400/30 text-cyan-400 hover:bg-cyan-400/10 transition-all duration-300"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/30 text-white hover:bg-white/10 bg-transparent flex-1 transition-all duration-300"
                      asChild
                    >
                      <Link href={project.github} target="_blank">
                        <Github className="mr-2 h-4 w-4" />
                        Code
                      </Link>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-cyan-400/30 text-cyan-400 hover:bg-cyan-400/10 bg-transparent flex-1 transition-all duration-300"
                      asChild
                    >
                      <Link href={project.demo} target="_blank">
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Demo
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Contact Section */}
      <section id="contact" className="relative py-24 px-6 bg-black/20">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in-up">
              Let's Build Something{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Amazing
              </span>
            </h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto animate-fade-in-up animation-delay-300">
              Ready to transform your infrastructure? Let's discuss your next project and create scalable solutions
              together.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8 animate-fade-in-up animation-delay-500">
              <div className="space-y-6">
                {[
                  {
                    icon: <Mail className="h-6 w-6" />,
                    label: "Email",
                    value: "hmaidi.mohamed@example.com",
                    href: "mailto:hmaidi.mohamed@example.com",
                    color: "from-blue-500 to-cyan-500",
                  },
                  {
                    icon: <Phone className="h-6 w-6" />,
                    label: "Phone",
                    value: "+216 XX XXX XXX",
                    href: "tel:+216xxxxxxxx",
                    color: "from-green-500 to-emerald-500",
                  },
                  {
                    icon: <MapPin className="h-6 w-6" />,
                    label: "Location",
                    value: "Tunisia",
                    href: "#",
                    color: "from-purple-500 to-pink-500",
                  },
                ].map((contact, index) => (
                  <div key={index} className="flex items-center space-x-4 group">
                    <div
                      className={`w-14 h-14 bg-gradient-to-r ${contact.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
                    >
                      <div className="text-white">{contact.icon}</div>
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-lg">{contact.label}</h3>
                      <Link
                        href={contact.href}
                        className="text-cyan-400 hover:text-cyan-300 transition-colors duration-300 text-lg"
                      >
                        {contact.value}
                      </Link>
                    </div>
                  </div>
                ))}
              </div>

              {/* Social Links */}
              <div className="pt-8 border-t border-white/10">
                <h3 className="text-white font-semibold text-lg mb-4">Connect with me</h3>
                <div className="flex space-x-4">
                  {[
                    { icon: <Github className="h-5 w-5" />, href: "https://github.com/hmaidimohamed", label: "GitHub" },
                    {
                      icon: <Linkedin className="h-5 w-5" />,
                      href: "https://linkedin.com/in/hmaidimohamed",
                      label: "LinkedIn",
                    },
                  ].map((social, index) => (
                    <Link
                      key={index}
                      href={social.href}
                      target="_blank"
                      className="w-12 h-12 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center text-white hover:text-cyan-400 hover:bg-white/10 hover:border-cyan-400/30 transition-all duration-300 group"
                    >
                      <div className="group-hover:scale-110 transition-transform duration-300">{social.icon}</div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm animate-fade-in-up animation-delay-700">
              <CardContent className="p-8">
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-white font-medium">Name</label>
                      <Input
                        placeholder="Your Name"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-cyan-400 focus:ring-cyan-400/20 transition-all duration-300"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-white font-medium">Email</label>
                      <Input
                        type="email"
                        placeholder="Your Email"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-cyan-400 focus:ring-cyan-400/20 transition-all duration-300"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-white font-medium">Subject</label>
                    <Input
                      placeholder="Project Discussion"
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-cyan-400 focus:ring-cyan-400/20 transition-all duration-300"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-white font-medium">Message</label>
                    <Textarea
                      placeholder="Tell me about your project..."
                      rows={5}
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-cyan-400 focus:ring-cyan-400/20 resize-none transition-all duration-300"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white border-0 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-cyan-500/25"
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Enhanced Footer */}
      <footer className="relative py-12 px-6 border-t border-white/10">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-xl flex items-center justify-center">
                <Server className="h-6 w-6 text-white" />
              </div>
              <div>
                <span className="text-white font-bold text-xl">Hmaidi Mohamed</span>
                <p className="text-white/60 text-sm">Junior DevOps Engineer</p>
              </div>
            </div>

            <p className="text-white/60 text-center mb-4 md:mb-0">
              © 2024 Hmaidi Mohamed. Crafted with passion and cutting-edge technology.
            </p>

            <div className="flex items-center space-x-4">
              <Link
                href="https://github.com/hmaidimohamed"
                target="_blank"
                className="text-white/60 hover:text-cyan-400 transition-colors duration-300"
              >
                <Github className="h-5 w-5" />
              </Link>
              <Link
                href="https://linkedin.com/in/hmaidimohamed"
                target="_blank"
                className="text-white/60 hover:text-cyan-400 transition-colors duration-300"
              >
                <Linkedin className="h-5 w-5" />
              </Link>
              <Link
                href="mailto:hmaidi.mohamed@example.com"
                className="text-white/60 hover:text-cyan-400 transition-colors duration-300"
              >
                <Mail className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Enhanced Gallery Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative max-w-6xl w-full">
            {/* Close button */}
            <button
              onClick={closeGallery}
              className="absolute top-4 right-4 z-10 w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
            >
              <X className="h-6 w-6" />
            </button>

            {/* Image */}
            <div className="relative">
              <Image
                src={selectedProject.images[currentImageIndex] || "/placeholder.svg"}
                alt={`${selectedProject.title} - Image ${currentImageIndex + 1}`}
                width={1200}
                height={800}
                className="w-full h-auto max-h-[70vh] object-contain rounded-2xl"
              />

              {/* Navigation arrows */}
              {selectedProject.images.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 w-14 h-14 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 w-14 h-14 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300 hover:scale-110"
                  >
                    <ChevronRight className="h-6 w-6" />
                  </button>
                </>
              )}
            </div>

            {/* Project info */}
            <div className="mt-8 text-center">
              <h3 className="text-3xl font-bold text-white mb-4">{selectedProject.title}</h3>
              <p className="text-white/80 mb-6 max-w-3xl mx-auto leading-relaxed">
                {selectedProject.longDescription || selectedProject.description}
              </p>

              {/* Project Metrics */}
              {selectedProject.metrics && (
                <div className="grid grid-cols-3 gap-6 mb-6 max-w-md mx-auto">
                  {Object.entries(selectedProject.metrics).map(([key, value], metricIndex) => (
                    <div key={metricIndex} className="text-center p-4 bg-white/5 rounded-xl">
                      <div className="text-cyan-400 font-bold text-lg">{value}</div>
                      <div className="text-white/60 text-sm capitalize">{key.replace("_", " ")}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Image counter */}
              {selectedProject.images.length > 1 && (
                <div className="flex justify-center space-x-2 mb-6">
                  {selectedProject.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentImageIndex ? "bg-cyan-400 scale-125" : "bg-white/30 hover:bg-white/50"
                      }`}
                    />
                  ))}
                </div>
              )}

              <div className="flex flex-wrap gap-3 justify-center mb-6">
                {selectedProject.tech.map((tech, techIndex) => (
                  <Badge
                    key={techIndex}
                    className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border-cyan-400/30"
                  >
                    {tech}
                  </Badge>
                ))}
              </div>

              <div className="flex justify-center space-x-4">
                <Button
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 bg-transparent"
                  asChild
                >
                  <Link href={selectedProject.github} target="_blank">
                    <Github className="mr-2 h-4 w-4" />
                    View Code
                  </Link>
                </Button>
                <Button
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white border-0"
                  asChild
                >
                  <Link href={selectedProject.demo} target="_blank">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Live Demo
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
